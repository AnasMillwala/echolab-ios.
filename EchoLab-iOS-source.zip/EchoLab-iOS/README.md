# EchoLab for iPhone (version 0.2.0, demo)

Live monitoring with digital delay, reverb, compressor, tone EQ, limiter, howl protection,
delay and feedback quick presets, and an M4A recorder. Same glass look as the Android app.

Build: the GitHub workflow `ios.yml` runs XcodeGen on a Mac runner and produces an UNSIGNED
EchoLab.ipa. It must be signed by a sideloading tool (AltStore, Sideloadly) or by an Apple
Developer account before it will install on an iPhone.

Not in this first version (Android only for now): AUTO latency calibration, noise check,
upside-down portrait (iPhones do not allow it).
