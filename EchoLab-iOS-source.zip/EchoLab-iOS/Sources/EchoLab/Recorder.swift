import AVFoundation
import Foundation

/// Saves the processed sound (everything you hear, with all effects) as an M4A (AAC) file in the
/// app's Documents folder, which shows up in the Files app under EchoLab.
final class Recorder {
    private var file: AVAudioFile?
    private var url: URL?
    private var timer: DispatchSourceTimer?
    private let queue = DispatchQueue(label: "echolab.recorder")
    private let lock = NSLock()
    private var framesWritten: Int64 = 0
    private var rate: Double = 48000

    var seconds: Int {
        lock.lock()
        defer { lock.unlock() }
        return Int(framesWritten / Int64(max(rate, 1)))
    }

    func start(engine: EchoEngine, sampleRate: Double) throws -> URL {
        let df = DateFormatter()
        df.locale = Locale(identifier: "en_US_POSIX")
        df.dateFormat = "yyyyMMdd_HHmmss"
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let u = dir.appendingPathComponent("EchoLab_\(df.string(from: Date())).m4a")
        let settings: [String: Any] = [
            AVFormatIDKey: kAudioFormatMPEG4AAC,
            AVSampleRateKey: sampleRate,
            AVNumberOfChannelsKey: 1,
            AVEncoderBitRateKey: 128000
        ]
        let f = try AVAudioFile(forWriting: u, settings: settings)
        lock.lock()
        framesWritten = 0
        rate = sampleRate
        lock.unlock()
        file = f
        url = u
        engine.recStart()
        let t = DispatchSource.makeTimerSource(queue: queue)
        t.schedule(deadline: .now() + 0.05, repeating: 0.05)
        t.setEventHandler { [weak self] in self?.drain(engine) }
        timer = t
        t.resume()
        return u
    }

    private func drain(_ engine: EchoEngine) {
        guard let f = file else { return }
        let fmt = f.processingFormat
        var tmp = [Float](repeating: 0, count: 8192)
        while true {
            let n = Int(tmp.withUnsafeMutableBufferPointer { engine.recRead(into: $0.baseAddress!, max: 8192) })
            if n <= 0 { break }
            guard let buf = AVAudioPCMBuffer(pcmFormat: fmt, frameCapacity: AVAudioFrameCount(n)) else { break }
            buf.frameLength = AVAudioFrameCount(n)
            if let ch = buf.floatChannelData {
                tmp.withUnsafeBufferPointer { src in
                    ch[0].update(from: src.baseAddress!, count: n)
                }
            }
            try? f.write(from: buf)
            lock.lock()
            framesWritten += Int64(n)
            lock.unlock()
        }
    }

    /// Stops recording and returns the saved file (nil if nothing was recorded).
    func stop(engine: EchoEngine) -> URL? {
        engine.recStop()
        timer?.cancel()
        timer = nil
        queue.sync { self.drain(engine) }
        lock.lock()
        let had = framesWritten > 0
        lock.unlock()
        let u = url
        file = nil
        url = nil
        if !had, let u = u {
            try? FileManager.default.removeItem(at: u)
            return nil
        }
        return u
    }
}
