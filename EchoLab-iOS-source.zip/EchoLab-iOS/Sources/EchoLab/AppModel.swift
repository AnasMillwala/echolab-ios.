import AVFoundation
import SwiftUI
import UIKit

@MainActor
final class AppModel: ObservableObject {
    let engine = EchoEngine.shared()
    private let d = UserDefaults.standard
    private let recorder = Recorder()

    // MARK: settings (each one is saved and sent to the audio engine when changed)
    @Published var inGain = 0 { didSet { d.set(inGain, forKey: "inGain"); engine.setParam(0, value: Self.dbToLin(inGain)) } }
    @Published var outGain = 0 { didSet { d.set(outGain, forKey: "outGain"); engine.setParam(1, value: Self.dbToLin(outGain)) } }
    @Published var delayMs = 300 { didSet { d.set(delayMs, forKey: "delayMs"); engine.setParam(2, value: Float(delayMs)) } }
    @Published var feedback = 35 { didSet { d.set(feedback, forKey: "fb"); engine.setParam(3, value: Float(feedback) / 100) } }
    @Published var mix = 30 { didSet { d.set(mix, forKey: "mix"); engine.setParam(4, value: Float(mix) / 100) } }
    @Published var revAmt = 0 { didSet { d.set(revAmt, forKey: "revAmt"); engine.setParam(16, value: Float(revAmt)) } }
    @Published var revRoom = 50 { didSet { d.set(revRoom, forKey: "revRoom"); engine.setParam(17, value: Float(revRoom)) } }
    @Published var comp = 0 { didSet { d.set(comp, forKey: "comp"); engine.setParam(15, value: Float(comp)) } }
    @Published var bass = 0 { didSet { d.set(bass, forKey: "eqBass"); engine.setParam(9, value: Float(bass)) } }
    @Published var mid = 0 { didSet { d.set(mid, forKey: "eqMid"); engine.setParam(10, value: Float(mid)) } }
    @Published var treble = 0 { didSet { d.set(treble, forKey: "eqTreble"); engine.setParam(11, value: Float(treble)) } }
    @Published var limiter = true { didSet { d.set(limiter, forKey: "limiter"); engine.setParam(14, value: limiter ? 1 : 0) } }
    @Published var howlGuard = true { didSet { d.set(howlGuard, forKey: "howl"); engine.setParam(13, value: howlGuard ? 1 : 0) } }
    @Published var monitorOn = true { didSet { d.set(monitorOn, forKey: "monitor"); engine.setParam(6, value: monitorOn ? 1 : 0) } }
    @Published var bypass = false { didSet { d.set(bypass, forKey: "bypass"); engine.setParam(5, value: bypass ? 1 : 0) } }
    @Published var btCallMode = false { didSet { d.set(btCallMode, forKey: "btCall") } }
    @Published var wiredBufMs = 5 { didSet { d.set(wiredBufMs, forKey: "wiredBuf") } }
    @Published var btBufMs = 20 { didSet { d.set(btBufMs, forKey: "btBuf") } }
    @Published var applyComp = true { didSet { d.set(applyComp, forKey: "applyComp"); pushComp() } }
    @Published var delayPresets = [400, 500, 600, 700]
    @Published var feedbackPresets = [20, 35, 50, 65]

    // MARK: live state
    @Published var running = false
    @Published var recording = false
    @Published var recSeconds = 0
    @Published var message: String? = nil
    @Published var inLevel = 0
    @Published var outLevel = 0
    @Published var clips = 0
    @Published var howlActive = false
    @Published var wave = [Float](repeating: 0, count: 60)
    @Published var routeText = "Phone mic to speaker"
    @Published var inputs: [AVAudioSessionPortDescription] = []
    @Published var selectedInputUID: String? = nil
    @Published var orientationIndex = -1
    @Published var actualBufMs = 0.0
    @Published var measMs = -1.0
    @Published var appliedMs = 0 { didSet { pushComp() } }
    @Published var calSrc = "default"
    @Published var calBuf = -1
    @Published var measuring = false
    @Published var curKey = ""
    @Published var noiseReport: String? = nil
    private var tickCount = 0

    private var timer: Timer?
    private var messageToken = 0
    private let fullPresetKeys = ["inGain", "outGain", "delayMs", "fb", "mix", "revAmt", "revRoom",
                                  "comp", "eqBass", "eqMid", "eqTreble"]

    static func dbToLin(_ db: Int) -> Float { Float(pow(10.0, Double(db) / 20.0)) }

    var statusText: String {
        if let m = message { return m }
        return running ? "Monitoring ON" : "Stopped"
    }

    init() {
        func int(_ k: String, _ def: Int) -> Int { (UserDefaults.standard.object(forKey: k) as? Int) ?? def }
        func bool(_ k: String, _ def: Bool) -> Bool { (UserDefaults.standard.object(forKey: k) as? Bool) ?? def }
        inGain = int("inGain", 0)
        outGain = int("outGain", 0)
        delayMs = min(max(int("delayMs", 300), 1), 1500)
        feedback = int("fb", 35)
        mix = int("mix", 30)
        revAmt = int("revAmt", 0)
        revRoom = int("revRoom", 50)
        comp = int("comp", 0)
        bass = int("eqBass", 0)
        mid = int("eqMid", 0)
        treble = int("eqTreble", 0)
        limiter = bool("limiter", true)
        howlGuard = bool("howl", true)
        monitorOn = bool("monitor", true)
        bypass = bool("bypass", false)
        btCallMode = bool("btCall", false)
        wiredBufMs = min(max(int("wiredBuf", 5), 1), 100)
        btBufMs = min(max(int("btBuf", 20), 1), 100)
        applyComp = bool("applyComp", true)
        delayPresets = (0..<4).map { int("dpre\($0)", [400, 500, 600, 700][$0]) }
        feedbackPresets = (0..<4).map { int("fpre\($0)", [20, 35, 50, 65][$0]) }
        orientationIndex = int("orient", -1)
        applyAll()
        if orientationIndex >= 0 { applyOrientation() }

        let nc = NotificationCenter.default
        nc.addObserver(forName: AVAudioSession.routeChangeNotification, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.routeChanged() }
        }
        nc.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] note in
            let raw = note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt
            Task { @MainActor in self?.interruption(raw) }
        }
        configureCategory()
        refreshRoute()
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tick() }
        }
    }

    private func applyAll() {
        engine.setParam(0, value: Self.dbToLin(inGain))
        engine.setParam(1, value: Self.dbToLin(outGain))
        engine.setParam(2, value: Float(delayMs))
        engine.setParam(3, value: Float(feedback) / 100)
        engine.setParam(4, value: Float(mix) / 100)
        engine.setParam(5, value: bypass ? 1 : 0)
        engine.setParam(6, value: monitorOn ? 1 : 0)
        engine.setParam(9, value: Float(bass))
        engine.setParam(10, value: Float(mid))
        engine.setParam(11, value: Float(treble))
        engine.setParam(12, value: applyComp ? Float(appliedMs) : 0)
        engine.setParam(13, value: howlGuard ? 1 : 0)
        engine.setParam(14, value: limiter ? 1 : 0)
        engine.setParam(15, value: Float(comp))
        engine.setParam(16, value: Float(revAmt))
        engine.setParam(17, value: Float(revRoom))
    }

    // MARK: start / stop
    func toggleRun() { running ? stop() : start() }

    func start() {
        AVAudioSession.sharedInstance().requestRecordPermission { ok in
            Task { @MainActor in
                if ok { self.begin() }
                else { self.flash("Microphone permission is required. Turn it on in Settings > EchoLab.", 5) }
            }
        }
    }

    private func begin() {
        let s = AVAudioSession.sharedInstance()
        do {
            var opts: AVAudioSession.CategoryOptions = [.allowBluetoothA2DP, .defaultToSpeaker]
            if btCallMode { opts.insert(.allowBluetooth) }
            try s.setCategory(.playAndRecord, mode: .measurement, options: opts)
            try? s.setPreferredIOBufferDuration(Double(activeBufMs) / 1000.0)
            try? s.setPreferredSampleRate(48000)
            try s.setActive(true)
            if let uid = selectedInputUID, let p = s.availableInputs?.first(where: { $0.uid == uid }) {
                try? s.setPreferredInput(p)
            } else {
                try? s.setPreferredInput(nil)
            }
        } catch {
            flash("Could not start audio: \(error.localizedDescription)", 5)
            return
        }
        if engine.start(withSampleRate: s.sampleRate) {
            running = true
            message = nil
            refreshRoute()
            applyBuffer()
        } else {
            flash("Could not open audio with this input/output. Try Automatic, or replug the device.", 5)
        }
    }

    func stop() {
        if recording { stopRecording() }
        engine.stop()
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        running = false
    }

    private func restartIfRunning() {
        guard running else { return }
        if recording { stopRecording() }
        engine.stop()
        begin()
    }

    private func routeChanged() {
        refreshRoute()
        applyBuffer()
        guard running else { return }
        let sr = AVAudioSession.sharedInstance().sampleRate
        if abs(sr - engine.sampleRate) > 1 { restartIfRunning() }
    }

    private func interruption(_ raw: UInt?) {
        guard let raw = raw, let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }
        if type == .began {
            if recording { stopRecording() }
            engine.stop()
            flash("Paused: a call or another app is using audio.", 4)
        } else if running {
            begin()
        }
    }

    func refreshRoute() {
        let s = AVAudioSession.sharedInstance()
        inputs = s.availableInputs ?? []
        let i = s.currentRoute.inputs.first?.portName ?? "Phone mic"
        let o = s.currentRoute.outputs.first?.portName ?? "speaker"
        routeText = "\(i) to \(o)"
    }

    func selectInput(_ uid: String?) {
        selectedInputUID = uid
        if running {
            let s = AVAudioSession.sharedInstance()
            if let uid = uid, let p = s.availableInputs?.first(where: { $0.uid == uid }) { try? s.setPreferredInput(p) }
            else { try? s.setPreferredInput(nil) }
            refreshRoute()
        }
    }

    func settingsChangedNeedsRestart() { restartIfRunning() }

    // MARK: live readout
    private func toBar(_ p: Float) -> Int {
        if p <= 0.0001 { return 0 }
        return min(max(Int((20 * log10(Double(p)) + 60) / 60 * 100), 0), 100)
    }

    private func tick() {
        let ip = engine.takeInPeak()
        let op = engine.takeOutPeak()
        inLevel = toBar(ip)
        outLevel = toBar(op)
        wave.removeFirst()
        wave.append(Float(inLevel) / 100)
        clips = Int(engine.clipsNow())
        howlActive = engine.howlActiveNow()
        if recording { recSeconds = recorder.seconds }
        tickCount += 1
        if tickCount % 5 == 0 && running && !measuring {
            let k = routeKey()
            if k != curKey { curKey = k; loadCal() }
        }
        if tickCount % 10 == 0 { actualBufMs = AVAudioSession.sharedInstance().ioBufferDuration * 1000 }
    }

    func resetClips() { engine.resetClips() }

    // MARK: recording
    func toggleRec() {
        if recording { stopRecording(); return }
        guard running else { flash("Press START first. Recording captures the live sound.", 3); return }
        do {
            _ = try recorder.start(engine: engine, sampleRate: engine.sampleRate)
            recording = true
            recSeconds = 0
            flash("Recording...", 2)
        } catch {
            flash("Could not start recording: \(error.localizedDescription)", 5)
        }
    }

    func stopRecording() {
        let u = recorder.stop(engine: engine)
        recording = false
        if let u = u { flash("Saved in the Files app: EchoLab / \(u.lastPathComponent)", 8) }
        else { flash("Nothing was recorded.", 3) }
    }

    // MARK: quick presets (tap = load, hold 1 s = save the current value into that button only)
    func loadDelayPreset(_ i: Int) { delayMs = delayPresets[i]; flash("Loaded delay preset \(i + 1): \(delayPresets[i]) ms", 2.5) }
    func saveDelayPreset(_ i: Int) {
        delayPresets[i] = delayMs
        d.set(delayMs, forKey: "dpre\(i)")
        buzz()
        flash("Saved \(delayMs) ms to delay preset \(i + 1)", 2.5)
    }
    func loadFeedbackPreset(_ i: Int) { feedback = feedbackPresets[i]; flash("Loaded feedback preset \(i + 1): \(feedbackPresets[i]) %", 2.5) }
    func saveFeedbackPreset(_ i: Int) {
        feedbackPresets[i] = feedback
        d.set(feedback, forKey: "fpre\(i)")
        buzz()
        flash("Saved \(feedback) % to feedback preset \(i + 1)", 2.5)
    }

    // MARK: full settings presets (3 slots)
    private func currentValues() -> [String: Int] {
        ["inGain": inGain, "outGain": outGain, "delayMs": delayMs, "fb": feedback, "mix": mix,
         "revAmt": revAmt, "revRoom": revRoom, "comp": comp, "eqBass": bass, "eqMid": mid, "eqTreble": treble,
         "bypass": bypass ? 1 : 0, "monitor": monitorOn ? 1 : 0, "limiter": limiter ? 1 : 0, "howl": howlGuard ? 1 : 0]
    }

    func saveSlot(_ n: Int) {
        d.set(currentValues(), forKey: "preset:\(n)")
        flash("Saved to preset \(n)", 2.5)
    }

    func loadSlot(_ n: Int) {
        guard let v = d.dictionary(forKey: "preset:\(n)") as? [String: Int] else { flash("Preset \(n) is empty", 2.5); return }
        inGain = v["inGain"] ?? inGain
        outGain = v["outGain"] ?? outGain
        delayMs = v["delayMs"] ?? delayMs
        feedback = v["fb"] ?? feedback
        mix = v["mix"] ?? mix
        revAmt = v["revAmt"] ?? revAmt
        revRoom = v["revRoom"] ?? revRoom
        comp = v["comp"] ?? comp
        bass = v["eqBass"] ?? bass
        mid = v["eqMid"] ?? mid
        treble = v["eqTreble"] ?? treble
        if let b = v["bypass"] { bypass = b == 1 }
        if let m = v["monitor"] { monitorOn = m == 1 }
        if let l = v["limiter"] { limiter = l == 1 }
        if let h = v["howl"] { howlGuard = h == 1 }
        flash("Loaded preset \(n)", 2.5)
    }

    // MARK: orientation (iPhones cannot show upside-down portrait)
    func cycleOrientation() {
        orientationIndex = (orientationIndex + 1) % 3   // portrait, landscape left, landscape right
        d.set(orientationIndex, forKey: "orient")
        applyOrientation()
    }

    private func applyOrientation() {
        let masks: [UIInterfaceOrientationMask] = [.portrait, .landscapeLeft, .landscapeRight]
        let mask = masks[max(0, min(orientationIndex, 2))]
        AppDelegate.mask = mask
        guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene else { return }
        scene.requestGeometryUpdate(.iOS(interfaceOrientations: mask)) { _ in }
        scene.windows.first?.rootViewController?.setNeedsUpdateOfSupportedInterfaceOrientations()
    }

    // MARK: buffers (iPhone audio buffer size, separate for Bluetooth)
    var isBluetoothRoute: Bool {
        let s = AVAudioSession.sharedInstance()
        let bt: [AVAudioSession.Port] = [.bluetoothA2DP, .bluetoothHFP, .bluetoothLE]
        return (s.currentRoute.outputs + s.currentRoute.inputs).contains { bt.contains($0.portType) }
    }

    var activeBufMs: Int { isBluetoothRoute ? btBufMs : wiredBufMs }

    /// Asks the iPhone for the chosen buffer size. iOS only offers fixed sizes, so it rounds.
    func applyBuffer() {
        let s = AVAudioSession.sharedInstance()
        try? s.setPreferredIOBufferDuration(Double(activeBufMs) / 1000.0)
        actualBufMs = s.ioBufferDuration * 1000
    }

    private func configureCategory() {
        var opts: AVAudioSession.CategoryOptions = [.allowBluetoothA2DP, .defaultToSpeaker]
        if btCallMode { opts.insert(.allowBluetooth) }
        try? AVAudioSession.sharedInstance().setCategory(.playAndRecord, mode: .measurement, options: opts)
    }

    // MARK: latency calibration (per route)
    private func routeKey() -> String {
        let s = AVAudioSession.sharedInstance()
        let i = s.currentRoute.inputs.map { "\($0.portType.rawValue)-\($0.portName)" }.joined(separator: ",")
        let o = s.currentRoute.outputs.map { "\($0.portType.rawValue)-\($0.portName)" }.joined(separator: ",")
        return "\(i)|\(o)|\(Int(s.sampleRate))|\(btCallMode ? "call" : "std")"
    }

    private func loadCal() {
        let k = "cal:\(curKey)"
        measMs = (d.object(forKey: k + ":meas") as? Double) ?? -1
        calSrc = d.string(forKey: k + ":src") ?? "default"
        calBuf = (d.object(forKey: k + ":buf") as? Int) ?? -1
        appliedMs = (d.object(forKey: k + ":app") as? Int) ?? 0
        pushComp()
    }

    private func saveCal() {
        let k = "cal:\(curKey)"
        d.set(measMs, forKey: k + ":meas")
        d.set(appliedMs, forKey: k + ":app")
        d.set(calSrc, forKey: k + ":src")
        d.set(calBuf, forKey: k + ":buf")
    }

    private func pushComp() { engine.setParam(12, value: applyComp ? Float(appliedMs) : 0) }

    var calText: String {
        if curKey.isEmpty { return "Press START, then calibrate this route." }
        var t = "Measured round trip: " + (measMs >= 0 ? String(format: "%.1f ms", measMs) : "not measured")
        t += "\nApplied compensation: \(appliedMs) ms (\(calSrc)" + (applyComp ? "" : ", switched off") + ")"
        if measMs >= 0 && calSrc == "automatic" && calBuf != activeBufMs {
            t += "\nBuffer setting changed since measuring. Run AUTO again."
        }
        return t
    }

    func adjustComp(_ delta: Int) {
        guard !curKey.isEmpty else { flash("Press START first so the route is known.", 3); return }
        appliedMs = min(max(appliedMs + delta, 0), 500)
        calSrc = "manual override"
        saveCal()
    }

    func resetComp() {
        guard !curKey.isEmpty else { flash("Press START first so the route is known.", 3); return }
        appliedMs = 0; measMs = -1; calSrc = "default"; calBuf = -1
        saveCal()
    }

    private func waitForMeasurement() async -> [Double] {
        var r: [Double] = [2]
        var t = 0
        while r[0] == 2 && t < 40 {
            try? await Task.sleep(nanoseconds: 100_000_000)
            r = engine.measureResult().map { $0.doubleValue }
            t += 1
        }
        return r
    }

    func startMeasure() {
        guard running, !measuring, !curKey.isEmpty else { flash("Press START first, then AUTO.", 3); return }
        guard engine.measureStart(0) else { flash("Measurement could not start. Try again.", 3); return }
        measuring = true
        message = "Measuring... a short noise burst will play. Keep the room quiet."
        let keyAtStart = curKey
        Task { @MainActor in
            let r = await self.waitForMeasurement()
            self.measuring = false
            self.message = nil
            if self.curKey != keyAtStart { self.flash("Route changed during measurement. Run AUTO again.", 4); return }
            if r.count > 1 && r[0] == 4 {
                self.measMs = r[1]
                self.appliedMs = min(max(Int(r[1].rounded()), 0), 500)
                self.calSrc = "automatic"
                self.calBuf = self.activeBufMs
                self.saveCal()
                self.flash(String(format: "Calibration done: %.1f ms round trip.", r[1]), 4)
            } else {
                self.flash("No usable measurement. Turn up the volume, put the speaker near the mic (or use a loopback cable), and reduce background noise.", 6)
            }
        }
    }

    func startNoiseCheck() {
        guard running, !measuring else { flash("Press START first, then Noise check.", 3); return }
        guard engine.measureStart(1) else { flash("Noise check could not start.", 3); return }
        measuring = true
        message = "Noise check... stay quiet for a second."
        Task { @MainActor in
            let r = await self.waitForMeasurement()
            self.measuring = false
            self.message = nil
            if r.count > 5 && r[0] == 4 { self.noiseReport = Self.noiseText(r) }
            else { self.flash("Noise check failed. Try again.", 3) }
        }
    }

    private static func noiseText(_ r: [Double]) -> String {
        let level = r[1]
        var t = String(format: "Mic noise level: %.0f dBFS (peak %.0f dBFS)\n\n", level, r[2])
        if level < -85 { t += "The input is almost silent. The mic may be blocked, muted or not the selected one." }
        else if level < -60 { t += "Quiet. Any hiss you hear is not coming from this input." }
        else if level < -45 { t += "Moderate background noise. Normal for a phone mic in a room or a cheap adapter." }
        else { t += "Noisy. The room is loud, or the mic or cable is adding noise." }
        if r[4] > 0.25 && level > -85 {
            t += String(format: "\n\nMains hum at %.0f Hz makes up about %.0f%% of the noise. ", r[5], r[4] * 100)
            t += "It comes from outside the app (cable, ground loop, charger or nearby electronics). Try unplugging the charger or using another cable. Filtering it in software would damage the sound."
        }
        if abs(r[3]) > 0.01 { t += "\n\nThe input has a constant DC offset from the hardware. The app removes it." }
        t += "\n\nThis measures the mic input before any processing, so it cannot say whether the noise comes from the phone, the cable or the room. Repeat with another input, for example the built-in mic, and compare: if only one input is noisy, that device or cable is the cause."
        return t
    }

    // MARK: quick routes (USB-C)
    func quickRoute(usbIn: Bool) {
        configureCategory()
        refreshRoute()
        let s = AVAudioSession.sharedInstance()
        guard s.currentRoute.outputs.contains(where: { $0.portType == .usbAudio }) else {
            flash("No USB-C audio output found. Plug the device in and try again.", 4)
            return
        }
        let want: AVAudioSession.Port = usbIn ? .usbAudio : .builtInMic
        guard let i = s.availableInputs?.first(where: { $0.portType == want }) else {
            flash(usbIn ? "No USB-C audio input found. This device may only support output." : "No built-in microphone found.", 4)
            return
        }
        selectedInputUID = i.uid
        try? s.setPreferredInput(i)
        refreshRoute()
        flash("Route set: \(i.portName) to USB-C out", 4)
    }

    // MARK: helpers
    func flash(_ text: String, _ seconds: Double) {
        message = text
        messageToken += 1
        let token = messageToken
        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) { [weak self] in
            Task { @MainActor in
                if let self = self, self.messageToken == token { self.message = nil }
            }
        }
    }

    private func buzz() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }

    func diagnostics() -> String {
        let s = AVAudioSession.sharedInstance()
        var t = "EchoLab iOS 0.2.0 (demo)\n"
        t += "iOS \(UIDevice.current.systemVersion), \(UIDevice.current.model)\n"
        t += "Route: \(routeText)\n"
        t += "Sample rate \(Int(s.sampleRate)) Hz, IO buffer \(String(format: "%.1f", s.ioBufferDuration * 1000)) ms\n"
        t += "Input latency \(String(format: "%.1f", s.inputLatency * 1000)) ms, output latency \(String(format: "%.1f", s.outputLatency * 1000)) ms\n"
        t += "Bluetooth call mode: \(btCallMode)\n"
        t += "Buffer requested: wired \(wiredBufMs) ms, Bluetooth \(btBufMs) ms, in use now \(String(format: "%.1f", actualBufMs)) ms\n"
        t += "Measured round trip \(measMs) ms, applied \(appliedMs) ms (\(calSrc))\n"
        t += "Howl events \(engine.howlEventsNow())\n"
        t += "Recording: \(recording)\n"
        return t
    }
}
