#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// Low-latency live audio engine (RemoteIO). The audio session must be configured and active
/// before start. Parameter ids: 0 input gain (linear), 1 output gain (linear), 2 delay ms,
/// 3 feedback 0-1, 4 mix 0-1, 5 bypass, 6 monitor on, 9 bass dB, 10 mid dB, 11 treble dB,
/// 13 howl protection, 14 limiter, 15 compressor 0-100, 16 reverb 0-100, 17 room 0-100.
@interface EchoEngine : NSObject

+ (instancetype)shared;

@property (nonatomic, readonly) double sampleRate;
@property (nonatomic, readonly) BOOL isRunning;

- (BOOL)startWithSampleRate:(double)sampleRate;
- (void)stop;
- (void)setParam:(int)pid value:(float)value;

- (float)takeInPeak;
- (float)takeOutPeak;
- (int)clipsNow;
- (void)resetClips;
- (BOOL)howlActiveNow;
- (int)howlEventsNow;

/// Mode 0: latency measurement (plays a short noise burst, listens with the mic).
/// Mode 1: noise check (silent, measures the mic only). Returns NO if one is already running.
- (BOOL)measureStart:(int)mode;
/// [state, a, b, c, d, e]: state 0 idle, 2 running, 4 done, 5 failed. See EchoDsp.hpp.
- (NSArray<NSNumber *> *)measureResult;

- (void)recStart;
- (void)recStop;
- (int)recReadInto:(float *)dst max:(int)maxCount;

@end

NS_ASSUME_NONNULL_END
