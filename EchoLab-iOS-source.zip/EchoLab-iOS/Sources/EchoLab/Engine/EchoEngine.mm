#import "EchoEngine.h"
#import <AudioToolbox/AudioToolbox.h>
#include <memory>
#include <vector>
#include <cstring>
#include "EchoDsp.hpp"

namespace {
struct Core {
    echo::Dsp dsp;
    AudioUnit unit = nullptr;
    std::vector<float> inBuf = std::vector<float>(8192, 0.f);
    std::vector<float> outBuf = std::vector<float>(8192, 0.f);
};

OSStatus renderCallback(void* ref, AudioUnitRenderActionFlags* flags, const AudioTimeStamp* ts,
                        UInt32 bus, UInt32 frames, AudioBufferList* io) {
    Core* c = static_cast<Core*>(ref);
    if (frames > c->inBuf.size()) {
        for (UInt32 b = 0; b < io->mNumberBuffers; b++) {
            memset(io->mBuffers[b].mData, 0, io->mBuffers[b].mDataByteSize);
        }
        return noErr;
    }
    AudioBufferList abl;
    abl.mNumberBuffers = 1;
    abl.mBuffers[0].mNumberChannels = 1;
    abl.mBuffers[0].mDataByteSize = frames * sizeof(float);
    abl.mBuffers[0].mData = c->inBuf.data();
    OSStatus e = AudioUnitRender(c->unit, flags, ts, 1, frames, &abl);
    if (e != noErr) memset(c->inBuf.data(), 0, frames * sizeof(float));
    c->dsp.process(c->inBuf.data(), c->outBuf.data(), (int)frames);
    for (UInt32 b = 0; b < io->mNumberBuffers; b++) {
        UInt32 bytes = std::min<UInt32>(io->mBuffers[b].mDataByteSize, frames * sizeof(float));
        memcpy(io->mBuffers[b].mData, c->outBuf.data(), bytes);
    }
    return noErr;
}
}  // namespace

@implementation EchoEngine {
    std::unique_ptr<Core> _core;
    double _sampleRate;
    BOOL _running;
}

+ (instancetype)shared {
    static EchoEngine* e = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ e = [[EchoEngine alloc] init]; });
    return e;
}

- (instancetype)init {
    if ((self = [super init])) {
        _core.reset(new Core());
        _sampleRate = 48000;
    }
    return self;
}

- (double)sampleRate { return _sampleRate; }
- (BOOL)isRunning { return _running; }

- (void)teardown {
    if (_core->unit) {
        AudioOutputUnitStop(_core->unit);
        AudioUnitUninitialize(_core->unit);
        AudioComponentInstanceDispose(_core->unit);
        _core->unit = nullptr;
    }
    _running = NO;
}

- (BOOL)startWithSampleRate:(double)sampleRate {
    @synchronized (self) {
        [self teardown];
        _sampleRate = sampleRate;
        _core->dsp.prepare((float)sampleRate);

        AudioComponentDescription desc = {};
        desc.componentType = kAudioUnitType_Output;
        desc.componentSubType = kAudioUnitSubType_RemoteIO;
        desc.componentManufacturer = kAudioUnitManufacturer_Apple;
        AudioComponent comp = AudioComponentFindNext(NULL, &desc);
        if (!comp) return NO;
        if (AudioComponentInstanceNew(comp, &_core->unit) != noErr) return NO;

        UInt32 one = 1;
        if (AudioUnitSetProperty(_core->unit, kAudioOutputUnitProperty_EnableIO,
                                 kAudioUnitScope_Input, 1, &one, sizeof(one)) != noErr) {
            [self teardown]; return NO;
        }
        AudioUnitSetProperty(_core->unit, kAudioOutputUnitProperty_EnableIO,
                             kAudioUnitScope_Output, 0, &one, sizeof(one));

        AudioStreamBasicDescription mono = {};
        mono.mSampleRate = sampleRate;
        mono.mFormatID = kAudioFormatLinearPCM;
        mono.mFormatFlags = kAudioFormatFlagIsFloat | kAudioFormatFlagIsPacked |
                            kAudioFormatFlagIsNonInterleaved;
        mono.mBitsPerChannel = 32;
        mono.mChannelsPerFrame = 1;
        mono.mFramesPerPacket = 1;
        mono.mBytesPerFrame = 4;
        mono.mBytesPerPacket = 4;
        AudioStreamBasicDescription stereo = mono;
        stereo.mChannelsPerFrame = 2;

        // Mic data comes out of bus 1; speaker data goes into bus 0.
        if (AudioUnitSetProperty(_core->unit, kAudioUnitProperty_StreamFormat,
                                 kAudioUnitScope_Output, 1, &mono, sizeof(mono)) != noErr ||
            AudioUnitSetProperty(_core->unit, kAudioUnitProperty_StreamFormat,
                                 kAudioUnitScope_Input, 0, &stereo, sizeof(stereo)) != noErr) {
            [self teardown]; return NO;
        }
        AURenderCallbackStruct cb;
        cb.inputProc = renderCallback;
        cb.inputProcRefCon = _core.get();
        if (AudioUnitSetProperty(_core->unit, kAudioUnitProperty_SetRenderCallback,
                                 kAudioUnitScope_Input, 0, &cb, sizeof(cb)) != noErr) {
            [self teardown]; return NO;
        }
        if (AudioUnitInitialize(_core->unit) != noErr) { [self teardown]; return NO; }
        if (AudioOutputUnitStart(_core->unit) != noErr) { [self teardown]; return NO; }
        _running = YES;
        return YES;
    }
}

- (void)stop {
    @synchronized (self) { [self teardown]; }
}

- (void)setParam:(int)pid value:(float)v {
    echo::Dsp& d = _core->dsp;
    switch (pid) {
        case 0: d.inGain = v; break;
        case 1: d.outGain = v; break;
        case 2: d.delayMs = v; break;
        case 3: d.feedback = v; break;
        case 4: d.mix = v; break;
        case 5: d.bypass = v; break;
        case 6: d.monitor = v; break;
        case 9: d.bassDb = v; break;
        case 10: d.midDb = v; break;
        case 11: d.trebleDb = v; break;
        case 13: d.howlEnable = v; break;
        case 14: d.limiterEnable = v; break;
        case 15: d.compAmt = v; break;
        case 16: d.revAmt = v; break;
        case 17: d.revRoom = v; break;
        default: break;
    }
}

- (float)takeInPeak { return _core->dsp.inPeak.exchange(0.f); }
- (float)takeOutPeak { return _core->dsp.outPeak.exchange(0.f); }
- (int)clipsNow { return _core->dsp.clipCount.load(); }
- (void)resetClips { _core->dsp.clipCount = 0; }
- (BOOL)howlActiveNow { return _core->dsp.howlHold.load() > 0; }
- (int)howlEventsNow { return _core->dsp.howlEvents.load(); }

- (void)recStart { _core->dsp.recStart(); }
- (void)recStop { _core->dsp.recStop(); }
- (int)recReadInto:(float *)dst max:(int)maxCount { return _core->dsp.recRead(dst, maxCount); }

@end
