// EchoLab DSP core (shared design with the Android engine): mic -> DC blocker -> input gain ->
// compressor -> digital delay (crossfaded) -> reverb -> 3-band tone -> output gain ->
// howl guard -> limiter. One mono input block in, one mono output block out.
#pragma once
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <vector>

namespace echo {

inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

struct Biquad {
    float b0 = 1.f, b1 = 0.f, b2 = 0.f, a1 = 0.f, a2 = 0.f, z1 = 0.f, z2 = 0.f;
    inline float process(float x) {
        float y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }
    void set(float nb0, float nb1, float nb2, float na0, float na1, float na2) {
        b0 = nb0 / na0; b1 = nb1 / na0; b2 = nb2 / na0; a1 = na1 / na0; a2 = na2 / na0;
    }
};

inline void lowShelf(Biquad& q, float sr, float f, float db) {
    f = std::min(f, 0.45f * sr);
    float A = std::pow(10.f, db / 40.f), w = 2.f * 3.14159265f * f / sr;
    float c = std::cos(w), s = std::sin(w), sA = std::sqrt(A);
    float al = s * 0.5f * 1.41421356f;
    q.set(A * ((A + 1) - (A - 1) * c + 2 * sA * al), 2 * A * ((A - 1) - (A + 1) * c),
          A * ((A + 1) - (A - 1) * c - 2 * sA * al), (A + 1) + (A - 1) * c + 2 * sA * al,
          -2 * ((A - 1) + (A + 1) * c), (A + 1) + (A - 1) * c - 2 * sA * al);
}

inline void highShelf(Biquad& q, float sr, float f, float db) {
    f = std::min(f, 0.45f * sr);
    float A = std::pow(10.f, db / 40.f), w = 2.f * 3.14159265f * f / sr;
    float c = std::cos(w), s = std::sin(w), sA = std::sqrt(A);
    float al = s * 0.5f * 1.41421356f;
    q.set(A * ((A + 1) + (A - 1) * c + 2 * sA * al), -2 * A * ((A - 1) + (A + 1) * c),
          A * ((A + 1) + (A - 1) * c - 2 * sA * al), (A + 1) - (A - 1) * c + 2 * sA * al,
          2 * ((A - 1) - (A + 1) * c), (A + 1) - (A - 1) * c - 2 * sA * al);
}

inline void peaking(Biquad& q, float sr, float f, float Q, float db) {
    f = std::min(f, 0.45f * sr);
    float A = std::pow(10.f, db / 40.f), w = 2.f * 3.14159265f * f / sr;
    float c = std::cos(w), al = std::sin(w) / (2.f * Q);
    q.set(1 + al * A, -2 * c, 1 - al * A, 1 + al / A, -2 * c, 1 - al / A);
}

struct Comb {
    std::vector<float> b;
    int i = 0;
    float store = 0.f;
    void init(int n) { b.assign(n, 0.f); i = 0; store = 0.f; }
    inline float process(float in, float fb, float damp) {
        float out = b[i];
        store = out * (1.f - damp) + store * damp;
        b[i] = in + store * fb;
        if (++i >= (int)b.size()) i = 0;
        return out;
    }
};

struct AllPass {
    std::vector<float> b;
    int i = 0;
    void init(int n) { b.assign(n, 0.f); i = 0; }
    inline float process(float in) {
        float bo = b[i];
        float out = -in + bo;
        b[i] = in + bo * 0.5f;
        if (++i >= (int)b.size()) i = 0;
        return out;
    }
};

class Dsp {
public:
    // Parameters: written by the UI thread, read by the audio thread.
    std::atomic<float> inGain{1.f}, outGain{1.f}, delayMs{300.f}, feedback{0.35f}, mix{0.3f},
        bypass{0.f}, monitor{1.f}, bassDb{0.f}, midDb{0.f}, trebleDb{0.f}, howlEnable{1.f},
        limiterEnable{1.f}, compAmt{0.f}, revAmt{0.f}, revRoom{50.f}, compMs{0.f};
    // Latency measurement / noise check state: 0 idle, 1 requested, 2 running, 3 finished.
    std::atomic<int> measState{0}, measMode{0};
    std::atomic<int> howlHold{0}, howlEvents{0}, clipCount{0};
    std::atomic<float> inPeak{0.f}, outPeak{0.f};

    // Recording tap (lock-free single producer / single consumer ring of float samples).
    static constexpr int64_t kRecRing = 1 << 18, kRecMask = kRecRing - 1;
    std::atomic<bool> recOn{false};
    std::atomic<int64_t> recW{0}, recR{0};
    std::vector<float> recRing = std::vector<float>(kRecRing, 0.f);
    void recStart() { recR.store(recW.load()); recOn.store(true); }
    void recStop() { recOn.store(false); }
    int recRead(float* dst, int maxN) {
        int64_t r = recR.load(std::memory_order_relaxed);
        int64_t w = recW.load(std::memory_order_acquire);
        int n = (int)std::min<int64_t>(w - r, (int64_t)maxN);
        for (int i = 0; i < n; i++) dst[i] = recRing[(size_t)((r + i) & kRecMask)];
        recR.store(r + n, std::memory_order_release);
        return n;
    }

    void prepare(float sampleRate) {
        sr = sampleRate;
        bufSize = (int)(sr * 2.0f) + 4;
        dl.assign((size_t)bufSize, 0.f);
        wIdx = 0;
        sIn = inGain.load(); sOut = outGain.load(); sFb = feedback.load();
        sMix = bypass.load() > 0.5f ? 0.f : mix.load();
        sMon = monitor.load();
        dA = dB = clampf((delayMs.load() - clampf(compMs.load(), 0.f, 500.f)) * sr * 0.001f, 1.f, (float)(bufSize - 3));
        xf = 1.f; xfActive = false;
        sBass = clampf(bassDb.load(), -12.f, 12.f);
        sMid = clampf(midDb.load(), -12.f, 12.f);
        sTreble = clampf(trebleDb.load(), -12.f, 12.f);
        eqLow = Biquad(); eqMid = Biquad(); eqHigh = Biquad();
        howlPos = 0; howlRise = 0; howlLoud = 0; howlPrev = 0.f; sHowl = 1.f;
        howlHold.store(0);
        const int cb[8] = {1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617};
        const int ab[4] = {556, 441, 341, 225};
        float scale = sr / 44100.f;
        for (int i = 0; i < 8; i++) combs[i].init(std::max(8, (int)(cb[i] * scale)));
        for (int i = 0; i < 4; i++) aps[i].init(std::max(8, (int)(ab[i] * scale)));
        sRev = clampf(revAmt.load(), 0.f, 100.f) * 0.01f;
        sRoom = clampf(revRoom.load(), 0.f, 100.f) * 0.01f;
        sComp = clampf(compAmt.load(), 0.f, 100.f) * 0.01f;
        cEnv = 0.f; limEnv = 1.f;
        lowShelf(eqLow, sr, 120.f, sBass);
        peaking(eqMid, sr, 1000.f, 0.7f, sMid);
        highShelf(eqHigh, sr, 6000.f, sTreble);
        dcX = dcY = 0.f;
        dcR = 1.f - 2.f * 3.14159265f * 5.f / sr;
        probeLen = (int)(sr * 0.08f);
        maxLag = (int)(sr * 0.5f);
        recLen = probeLen + maxLag;
        rec.assign((size_t)recLen, 0.f);
        probe.assign((size_t)probeLen, 0.f);
        uint32_t seed = 12345u;
        const float fade = 0.005f * sr;
        for (int i = 0; i < probeLen; i++) {
            seed = seed * 1664525u + 1013904223u;
            float rr = (float)((seed >> 8) & 0xFFFF) / 32768.f - 1.f;
            float f = std::min(1.f, std::min((float)i, (float)(probeLen - 1 - i)) / fade);
            probe[(size_t)i] = 0.4f * rr * f;
        }
        measState.store(0);
        mPos = 0;
    }

    bool requestMeasure(int mode) {
        int st = measState.load();
        if (recLen == 0 || st == 1 || st == 2) return false;
        measMode.store(mode);
        measState.store(1);
        return true;
    }

    // r[0]: 0 idle, 2 running, 4 ok, 5 failed. Latency mode: r[1] round trip ms, r[2] quality.
    // Noise mode: r[1] rms dBFS, r[2] peak dBFS, r[3] DC offset, r[4] hum share, r[5] hum Hz.
    void measureResult(float* r) {
        for (int k = 0; k < 6; k++) r[k] = 0.f;
        int st = measState.load();
        if (st == 1 || st == 2) { r[0] = 2.f; return; }
        if (st != 3) return;
        if (recLen == 0 || (int)rec.size() != recLen) { measState.store(0); r[0] = 5.f; return; }
        if (measMode.load() == 1) { analyzeNoise(r); measState.store(0); return; }
        std::vector<float> c((size_t)maxLag);
        float best = 0.f;
        int bestD = 0;
        for (int d = 0; d < maxLag; d++) {
            const float* rp = rec.data() + d;
            float acc = 0.f;
            for (int k = 0; k < probeLen; k++) acc += probe[(size_t)k] * rp[k];
            c[(size_t)d] = std::fabs(acc);
            if (c[(size_t)d] > best) { best = c[(size_t)d]; bestD = d; }
        }
        int excl = (int)(sr * 0.002f);
        double s2 = 0.0;
        int cnt = 0;
        for (int d = 0; d < maxLag; d++) {
            if (std::abs(d - bestD) > excl) { s2 += c[(size_t)d]; cnt++; }
        }
        float mean = cnt > 0 ? (float)(s2 / cnt) : 1.f;
        float q = mean > 1e-9f ? best / mean : 0.f;
        r[1] = (float)bestD * 1000.f / sr;
        r[2] = q;
        r[0] = (q > 7.f && bestD > 2 && bestD < maxLag - 2) ? 4.f : 5.f;
        measState.store(0);
    }

    void process(const float* in, float* out, int numFrames) {
        const float tHowl = howlHold.load() > 0 ? 0.1f : 1.f;
        float pkIn = 0.f, pkOut = 0.f;
        int clips = 0;
        const float aFast = 1.f - std::exp(-1.f / (sr * 0.02f));
        const float aFb = 1.f - std::exp(-1.f / (sr * 0.15f));
        const float aMix = 1.f - std::exp(-1.f / (sr * 0.05f));
        const float xfInc = 1.f / (sr * 0.08f);
        const float tIn = inGain.load(), tOut = outGain.load(), tDelay = delayMs.load();
        const float tFb = clampf(feedback.load(), 0.f, 0.9f);
        const float tMix = bypass.load() > 0.5f ? 0.f : clampf(mix.load(), 0.f, 1.f);
        const float tMon = monitor.load() > 0.5f ? 1.f : 0.f;
        const float tComp = clampf(compAmt.load(), 0.f, 100.f) * 0.01f;
        const float tRev = clampf(revAmt.load(), 0.f, 100.f) * 0.01f;
        const float tRoom = clampf(revRoom.load(), 0.f, 100.f) * 0.01f;
        const bool limOn = limiterEnable.load() > 0.5f;
        const float cAtk = 1.f - std::exp(-1.f / (sr * 0.005f));
        const float cRel = 1.f - std::exp(-1.f / (sr * 0.12f));
        const float limRel = 1.f - std::exp(-1.f / (sr * 0.08f));
        const float tgtSamp = clampf((tDelay - clampf(compMs.load(), 0.f, 500.f)) * sr * 0.001f, 1.f, (float)(bufSize - 3));
        {
            const float k = 1.f - std::exp(-(float)numFrames / (sr * 0.05f));
            sBass += k * (clampf(bassDb.load(), -12.f, 12.f) - sBass);
            sMid += k * (clampf(midDb.load(), -12.f, 12.f) - sMid);
            sTreble += k * (clampf(trebleDb.load(), -12.f, 12.f) - sTreble);
            lowShelf(eqLow, sr, 120.f, sBass);
            peaking(eqMid, sr, 1000.f, 0.7f, sMid);
            highShelf(eqHigh, sr, 6000.f, sTreble);
        }
        const bool recNow = recOn.load(std::memory_order_relaxed);
        int64_t rw = recW.load(std::memory_order_relaxed);
        const int64_t rr0 = recR.load(std::memory_order_acquire);
        int ms = measState.load();
        if (ms == 1) { mPos = 0; measState.store(2); ms = 2; }
        const int mm = measMode.load();
        const float* dlp = dl.data();
        auto tap = [&](float d) -> float {
            float rp = (float)wIdx - d;
            if (rp < 0.f) rp += (float)bufSize;
            int i0 = std::min((int)rp, bufSize - 1);
            float fr = rp - (float)i0;
            int i1 = i0 + 1;
            if (i1 >= bufSize) i1 = 0;
            return dlp[i0] * (1.f - fr) + dlp[i1] * fr;
        };

        for (int i = 0; i < numFrames; i++) {
            if (ms == 2 && mPos < recLen) {  // measuring: play the probe (latency mode) and record the mic
                rec[(size_t)mPos] = in[i];
                float pv = (mm == 0 && mPos < probeLen) ? probe[(size_t)mPos] : 0.f;
                mPos++;
                out[i] = pv;
                continue;
            }
            sIn += aFast * (tIn - sIn);
            sOut += aFast * (tOut - sOut);
            sFb += aFb * (tFb - sFb);
            sMix += aMix * (tMix - sMix);
            sMon += aFast * (tMon - sMon);
            sHowl += aFast * (tHowl - sHowl);
            sComp += aMix * (tComp - sComp);
            sRev += aMix * (tRev - sRev);
            sRoom += aFb * (tRoom - sRoom);

            float xin = in[i];
            float y = xin - dcX + dcR * dcY;
            dcX = xin;
            dcY = y;
            float x = y * sIn;
            pkIn = std::max(pkIn, std::fabs(x));
            howlBuf[howlPos++] = x;
            if (howlPos >= 1024) { howlPos = 0; analyzeHowl(); }

            {
                float ax = std::fabs(x);
                cEnv += (ax > cEnv ? cAtk : cRel) * (ax - cEnv);
                if (sComp > 0.001f) {
                    float envDb = 20.f * std::log10(std::max(cEnv, 1e-6f));
                    float thr = -6.f - 24.f * sComp;
                    float ratio = 1.f + 5.f * sComp;
                    float over = envDb - thr;
                    float gr = over > 0.f ? over * (1.f - 1.f / ratio) : 0.f;
                    float makeup = -thr * (1.f - 1.f / ratio) * 0.4f;
                    x *= std::exp((makeup - gr) * 0.11512925f);
                }
            }

            if (!xfActive && std::fabs(tgtSamp - dB) > 0.5f) {
                dA = dB; dB = tgtSamp; xf = 0.f; xfActive = true;
            }
            float wet;
            if (xfActive) {
                xf += xfInc;
                if (xf >= 1.f) { xf = 1.f; xfActive = false; }
                wet = tap(dA) * std::cos(xf * 1.5707963f) + tap(dB) * std::sin(xf * 1.5707963f);
            } else {
                wet = tap(dB);
            }
            dl[(size_t)wIdx] = clampf(x + wet * sFb, -2.f, 2.f);
            if (++wIdx >= bufSize) wIdx = 0;

            float mixed = x * (1.f - sMix) + wet * sMix;
            {
                float revFb = 0.7f + 0.28f * sRoom;
                float rin = mixed * 0.015f, acc = 0.f;
                for (int c = 0; c < 8; c++) acc += combs[c].process(rin, revFb, 0.4f);
                for (int a = 0; a < 4; a++) acc = aps[a].process(acc);
                mixed += acc * 1.5f * sRev;
            }
            mixed = eqHigh.process(eqMid.process(eqLow.process(mixed)));
            float o = mixed * sOut * sMon * sHowl;
            if (limOn) {
                float a0 = std::fabs(o);
                float tg = a0 > 0.95f ? 0.95f / a0 : 1.f;
                if (tg < limEnv) limEnv = tg; else limEnv += limRel * (tg - limEnv);
                o *= limEnv;
            }
            if (recNow && rw - rr0 < kRecRing) {
                recRing[(size_t)(rw & kRecMask)] =
                    clampf(mixed * sOut * sHowl * (limOn ? limEnv : 1.f), -1.f, 1.f);
                rw++;
            }
            float ao = std::fabs(o);
            pkOut = std::max(pkOut, ao);
            if (ao > 1.f) { clips++; o = clampf(o, -1.f, 1.f); }
            out[i] = o;
        }
        if (ms == 2 && mPos >= recLen) measState.store(3);
        recW.store(rw, std::memory_order_release);
        inPeak.store(std::max(inPeak.load(), pkIn));
        outPeak.store(std::max(outPeak.load(), pkOut));
        if (clips) clipCount.fetch_add(clips);
    }

private:
    float sr = 48000.f;
    std::vector<float> dl;
    int bufSize = 4, wIdx = 0;
    float sIn = 1.f, sOut = 1.f, sFb = 0.f, sMix = 0.f, sMon = 1.f;
    float dcX = 0.f, dcY = 0.f, dcR = 0.9993f;
    float dA = 1.f, dB = 1.f, xf = 1.f;
    bool xfActive = false;
    Biquad eqLow, eqMid, eqHigh;
    float howlBuf[1024] = {0};
    int howlPos = 0, howlRise = 0, howlLoud = 0;
    float howlPrev = 0.f, sHowl = 1.f;
    Comb combs[8];
    AllPass aps[4];
    float sRev = 0.f, sRoom = 0.5f, sComp = 0.f, cEnv = 0.f, limEnv = 1.f;
    float sBass = 0.f, sMid = 0.f, sTreble = 0.f;
    std::vector<float> rec, probe;
    int probeLen = 0, recLen = 0, maxLag = 0, mPos = 0;

    // Measures the mic input with the output silent: level, DC offset and 50/60 Hz hum share.
    void analyzeNoise(float* r) {
        int skip = (int)(sr * 0.05f);
        int N = recLen - skip;
        if (N < 1024) { r[0] = 5.f; return; }
        const float* x = rec.data() + skip;
        double sum = 0.0, sq = 0.0;
        float peak = 0.f;
        for (int i = 0; i < N; i++) sum += x[i];
        double mean = sum / N;
        for (int i = 0; i < N; i++) {
            double d = x[i] - mean;
            sq += d * d;
            peak = std::max(peak, (float)std::fabs(d));
        }
        double var = sq / N;
        double rms = std::sqrt(var);
        auto tonePower = [&](double f) -> double {
            double coeff = 2.0 * std::cos(2.0 * 3.14159265358979 * f / sr);
            double s1 = 0.0, s2 = 0.0;
            for (int i = 0; i < N; i++) {
                double s0 = (x[i] - mean) + coeff * s1 - s2;
                s2 = s1;
                s1 = s0;
            }
            double p = s1 * s1 + s2 * s2 - coeff * s1 * s2;
            double A = 2.0 * std::sqrt(std::max(p, 0.0)) / N;
            return A * A / 2.0;
        };
        double h50 = tonePower(50) + tonePower(100) + tonePower(150);
        double h60 = tonePower(60) + tonePower(120) + tonePower(180);
        r[0] = 4.f;
        r[1] = 20.f * std::log10((float)rms + 1e-9f);
        r[2] = 20.f * std::log10(peak + 1e-9f);
        r[3] = (float)mean;
        r[4] = var > 1e-14 ? (float)std::min(1.0, std::max(h50, h60) / var) : 0.f;
        r[5] = h50 >= h60 ? 50.f : 60.f;
    }

    // Feedback (howl) detector: a loud, very periodic signal that keeps growing, or stays
    // loud and pure for about 0.4 s. Runs once per 1024 input samples.
    void analyzeHowl() {
        float e = 0.f;
        for (int i = 0; i < 1024; i++) e += howlBuf[i] * howlBuf[i];
        float rms = std::sqrt(e / 1024.f);
        bool tonal = false;
        if (rms > 0.08f) {
            float best = 0.f;
            for (int lag = 8; lag <= 300; lag++) {
                float acc = 0.f;
                for (int i = 0; i < 1024 - lag; i++) acc += howlBuf[i] * howlBuf[i + lag];
                float r = acc / (e * (float)(1024 - lag) / 1024.f);
                if (r > best) best = r;
            }
            tonal = best > 0.88f;
        }
        if (!tonal || rms < howlPrev * 0.97f) howlRise = 0;
        else if (rms > howlPrev * 1.04f) howlRise++;
        howlLoud = (tonal && rms > 0.4f) ? howlLoud + 1 : 0;
        howlPrev = rms;
        int hold = howlHold.load();
        if (hold > 0) {
            howlHold.store(hold - 1);
        } else if (howlEnable.load() > 0.5f &&
                   ((howlRise >= 4 && rms > 0.15f) || howlLoud >= 20)) {
            howlHold.store((int)(4.f * sr / 1024.f));
            howlEvents.fetch_add(1);
            howlRise = 0;
            howlLoud = 0;
        }
    }
};

}  // namespace echo
