import SwiftUI

struct RootView: View {
    @EnvironmentObject var m: AppModel
    @State private var tab = 0
    private let names = ["Monitor", "Delay", "Tone", "Setup"]

    var body: some View {
        GeometryReader { geo in
            let ins = geo.safeAreaInsets
            // When the app is drawn upside down, the notch side and the home-bar side swap.
            let top = m.flipped ? ins.bottom : ins.top
            let bottom = m.flipped ? ins.top : ins.bottom
            ZStack {
                Theme.bg
                VStack(spacing: 0) {
                    ZStack {
                        Text("EchoLab").font(.system(size: 20, weight: .bold)).foregroundColor(Theme.text)
                        HStack {
                            Spacer()
                            Button(action: { m.cycleOrientation() }) {
                                Image(systemName: "arrow.triangle.2.circlepath")
                                    .font(.system(size: 17, weight: .semibold))
                                    .foregroundColor(Theme.gold)
                                    .frame(width: 44, height: 44)
                                    .background(Circle().fill(Theme.gold.opacity(0.14)))
                                    .overlay(Circle().stroke(Theme.gold.opacity(0.7), lineWidth: 1))
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel("Turn screen")
                        }.padding(.trailing, 16)
                    }
                    .padding(.top, 6)
                    Text(m.statusText).font(.system(size: 13))
                        .foregroundColor(m.running && m.message == nil ? Theme.gold : Theme.muted)
                        .multilineTextAlignment(.center).padding(.horizontal, 16).padding(.bottom, 6)
                    Group {
                        switch tab {
                        case 0: MonitorView()
                        case 1: DelayView()
                        case 2: ToneView()
                        default: SetupView()
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    HStack(spacing: 0) {
                        ForEach(0..<4, id: \.self) { i in
                            Button(action: { tab = i }) {
                                VStack(spacing: 0) {
                                    Rectangle().fill(tab == i ? Theme.gold : Color.clear).frame(height: 2)
                                    Text(names[i]).font(.system(size: 13, weight: .bold))
                                        .foregroundColor(tab == i ? Theme.gold : Theme.muted)
                                        .frame(maxWidth: .infinity).padding(.vertical, 14)
                                }
                            }.buttonStyle(.plain)
                        }
                    }
                    .padding(.bottom, bottom)
                    .background(Color.black.opacity(0.3))
                }
                .padding(.top, top)
                .padding(.leading, ins.leading)
                .padding(.trailing, ins.trailing)
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .rotationEffect(.degrees(m.flipped ? 180 : 0))
        }
        .ignoresSafeArea()
        .statusBarHidden(m.flipped)
    }
}
