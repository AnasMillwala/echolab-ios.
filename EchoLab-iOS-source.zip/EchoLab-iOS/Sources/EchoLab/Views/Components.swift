import SwiftUI
import AVKit

enum Theme {
    static let gold = Color(red: 232 / 255, green: 195 / 255, blue: 122 / 255)
    static let text = Color(red: 232 / 255, green: 241 / 255, blue: 242 / 255)
    static let muted = Color(red: 169 / 255, green: 189 / 255, blue: 192 / 255)
    static let red = Color(red: 1.0, green: 0.353, blue: 0.372)
    static let bg = LinearGradient(
        colors: [Color(red: 11 / 255, green: 45 / 255, blue: 51 / 255),
                 Color(red: 10 / 255, green: 23 / 255, blue: 28 / 255),
                 Color(red: 23 / 255, green: 16 / 255, blue: 42 / 255)],
        startPoint: .top, endPoint: .bottom)
}

func signed(_ v: Int) -> String { v > 0 ? "+\(v)" : "\(v)" }

struct GlassCard<Content: View>: View {
    let title: String?
    let content: Content

    init(_ title: String? = nil, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let t = title {
                Text(t).font(.system(size: 18, weight: .bold)).foregroundColor(Theme.text)
            }
            content
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(LinearGradient(colors: [Color.white.opacity(0.10), Color.white.opacity(0.03)],
                                     startPoint: .topLeading, endPoint: .bottomTrailing)))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(Color.white.opacity(0.14), lineWidth: 1))
    }
}

struct Hint: View {
    let text: String
    init(_ t: String) { text = t }
    var body: some View {
        Text(text).font(.system(size: 12)).foregroundColor(Theme.muted)
            .fixedSize(horizontal: false, vertical: true)
    }
}

/// Round knob: drag up or down to change the value.
struct KnobView: View {
    let title: String
    @Binding var value: Int
    let range: ClosedRange<Int>
    let format: (Int) -> String
    var dragPoints: CGFloat = 220
    @State private var startValue: Int? = nil

    private var frac: Double {
        Double(value - range.lowerBound) / Double(max(range.upperBound - range.lowerBound, 1))
    }

    var body: some View {
        VStack(spacing: 4) {
            ZStack {
                Circle().trim(from: 0, to: 0.75)
                    .stroke(Color(red: 0.165, green: 0.227, blue: 0.251),
                            style: StrokeStyle(lineWidth: 5, lineCap: .round))
                    .rotationEffect(.degrees(135))
                    .frame(width: 72, height: 72)
                Circle().trim(from: 0, to: 0.75 * frac)
                    .stroke(Theme.gold, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                    .rotationEffect(.degrees(135))
                    .frame(width: 72, height: 72)
                Circle()
                    .fill(RadialGradient(colors: [Color(red: 0.227, green: 0.302, blue: 0.329),
                                                  Color(red: 0.043, green: 0.071, blue: 0.082)],
                                         center: UnitPoint(x: 0.4, y: 0.35), startRadius: 0, endRadius: 40))
                    .overlay(Circle().stroke(Color.black.opacity(0.5), lineWidth: 1))
                    .frame(width: 54, height: 54)
                ZStack {
                    Capsule().fill(Theme.gold).frame(width: 3, height: 17).offset(y: -15)
                }
                .frame(width: 54, height: 54)
                .rotationEffect(.degrees(-135 + 270 * frac))
            }
            .frame(width: 84, height: 84)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { g in
                        if startValue == nil { startValue = value }
                        let span = Double(range.upperBound - range.lowerBound)
                        let base = Double(startValue ?? value)
                        let nv = Int((base + Double(-g.translation.height) / Double(dragPoints) * span).rounded())
                        let clamped = min(max(nv, range.lowerBound), range.upperBound)
                        if clamped != value { value = clamped }
                    }
                    .onEnded { _ in startValue = nil })
            Text(title.uppercased()).font(.system(size: 11)).tracking(0.6).foregroundColor(Theme.muted)
            Text(format(value)).font(.system(size: 14, weight: .bold)).foregroundColor(Theme.gold)
        }
        .frame(maxWidth: .infinity)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(title)
        .accessibilityValue(format(value))
        .accessibilityAdjustableAction { dir in
            let step = max(1, (range.upperBound - range.lowerBound) / 50)
            switch dir {
            case .increment: value = min(value + step, range.upperBound)
            case .decrement: value = max(value - step, range.lowerBound)
            @unknown default: break
            }
        }
    }
}

struct SegMeter: View {
    let level: Int

    var body: some View {
        HStack(spacing: 2) {
            ForEach(0..<16, id: \.self) { i in
                RoundedRectangle(cornerRadius: 2)
                    .fill(color(i))
                    .opacity(i < Int((Double(level) / 100 * 16).rounded()) ? 1 : 0.22)
            }
        }
        .frame(height: 10)
    }

    private func color(_ i: Int) -> Color {
        if i < 10 { return Color(red: 0.29, green: 0.87, blue: 0.50) }
        if i < 13 { return Color(red: 0.96, green: 0.77, blue: 0.26) }
        return Color(red: 0.97, green: 0.44, blue: 0.44)
    }
}

struct WaveView: View {
    let samples: [Float]

    var body: some View {
        Canvas { ctx, size in
            let n = samples.count
            guard n > 0 else { return }
            let cy = size.height / 2
            for i in 0..<n {
                let amp = CGFloat(samples[i])
                let half = max(2, amp * size.height * 0.46)
                let x = (CGFloat(i) + 0.5) * size.width / CGFloat(n)
                var p = Path()
                p.move(to: CGPoint(x: x, y: cy - half))
                p.addLine(to: CGPoint(x: x, y: cy + half))
                let c = waveColor(Double(i) / Double(max(n - 1, 1)))
                ctx.stroke(p, with: .color(c.opacity(0.18)), style: StrokeStyle(lineWidth: 6, lineCap: .round))
                ctx.stroke(p, with: .color(c), style: StrokeStyle(lineWidth: 2.6, lineCap: .round))
            }
        }
        .frame(height: 100)
        .accessibilityHidden(true)
    }

    private func waveColor(_ f: Double) -> Color {
        let blue = (0.22, 0.74, 0.97), salmon = (0.91, 0.59, 0.48), gold = (0.96, 0.73, 0.26)
        let a = f < 0.5 ? blue : salmon
        let b = f < 0.5 ? salmon : gold
        let t = f < 0.5 ? f * 2 : (f - 0.5) * 2
        return Color(red: a.0 + (b.0 - a.0) * t, green: a.1 + (b.1 - a.1) * t, blue: a.2 + (b.2 - a.2) * t)
    }
}

struct EqCurve: View {
    let bass: Int
    let mid: Int
    let treble: Int

    var body: some View {
        Canvas { ctx, size in
            let w = size.width, h = size.height, cy = h / 2
            let k = h * 0.38 / 12
            let yb = cy - CGFloat(bass) * k, ym = cy - CGFloat(mid) * k, yt = cy - CGFloat(treble) * k
            let x1 = w * 0.14, x2 = w * 0.5, x3 = w * 0.86
            var grid = Path()
            grid.move(to: CGPoint(x: 0, y: cy))
            grid.addLine(to: CGPoint(x: w, y: cy))
            ctx.stroke(grid, with: .color(Color.white.opacity(0.18)),
                       style: StrokeStyle(lineWidth: 1, dash: [4, 5]))
            var p = Path()
            p.move(to: CGPoint(x: 0, y: yb))
            p.addLine(to: CGPoint(x: x1, y: yb))
            let c1 = (x1 + x2) / 2
            p.addCurve(to: CGPoint(x: x2, y: ym), control1: CGPoint(x: c1, y: yb), control2: CGPoint(x: c1, y: ym))
            let c2 = (x2 + x3) / 2
            p.addCurve(to: CGPoint(x: x3, y: yt), control1: CGPoint(x: c2, y: ym), control2: CGPoint(x: c2, y: yt))
            p.addLine(to: CGPoint(x: w, y: yt))
            ctx.stroke(p, with: .color(Theme.gold.opacity(0.2)), style: StrokeStyle(lineWidth: 8, lineCap: .round))
            ctx.stroke(p, with: .color(Theme.gold), style: StrokeStyle(lineWidth: 3, lineCap: .round))
            for pt in [CGPoint(x: x1, y: yb), CGPoint(x: x2, y: ym), CGPoint(x: x3, y: yt)] {
                ctx.fill(Path(ellipseIn: CGRect(x: pt.x - 5, y: pt.y - 5, width: 10, height: 10)),
                         with: .color(Theme.gold))
            }
        }
        .frame(height: 80)
        .accessibilityHidden(true)
    }
}

struct GlassSquare: View {
    let glyph: String
    let caption: String
    let active: Bool
    let action: () -> Void

    var body: some View {
        VStack(spacing: 4) {
            Button(action: action) {
                Text(glyph).font(.system(size: 16, weight: .bold)).foregroundColor(Theme.gold)
                    .frame(width: 52, height: 52)
                    .background(GlassFill(radius: 14, active: active))
            }
            .buttonStyle(.plain)
            Text(caption).font(.system(size: 12)).foregroundColor(Theme.muted)
        }
        .accessibilityElement(children: .combine)
    }
}

struct GlassFill: View {
    let radius: CGFloat
    let active: Bool

    var body: some View {
        RoundedRectangle(cornerRadius: radius, style: .continuous)
            .fill(LinearGradient(
                colors: active ? [Theme.gold.opacity(0.35), Theme.gold.opacity(0.15)]
                               : [Color.white.opacity(0.16), Color.white.opacity(0.04)],
                startPoint: .topLeading, endPoint: .bottomTrailing))
            .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous)
                .stroke(active ? Theme.gold : Color.white.opacity(0.16), lineWidth: 1))
    }
}

struct WideButton: View {
    let title: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title).font(.system(size: 14, weight: .bold)).foregroundColor(Theme.gold)
                .frame(maxWidth: .infinity, minHeight: 46)
                .background(GlassFill(radius: 14, active: false))
        }
        .buttonStyle(.plain)
    }
}

/// Tap = load. Hold for 1 second = save (a buzz confirms it).
struct PresetButton: View {
    let text: String
    let active: Bool
    let onTap: () -> Void
    let onHold: () -> Void
    @State private var pressed = false
    @State private var held = false

    var body: some View {
        Text(text)
            .font(.system(size: 15, weight: .bold))
            .foregroundColor(Theme.gold)
            .frame(maxWidth: .infinity, minHeight: 52)
            .background(GlassFill(radius: 14, active: active))
            .opacity(pressed ? 0.7 : 1)
            .contentShape(Rectangle())
            .onLongPressGesture(minimumDuration: 1.0, pressing: { p in
                pressed = p
                if p { held = false }
            }, perform: {
                held = true
                onHold()
            })
            .onTapGesture {
                if held { held = false; return }
                onTap()
            }
            .accessibilityAddTraits(.isButton)
            .accessibilityLabel(text)
            .accessibilityHint("Tap to load. Hold to save the current value here.")
    }
}

/// Apple's system output picker (speaker, headphones, Bluetooth, AirPlay).
struct RoutePicker: UIViewRepresentable {
    func makeUIView(context: Context) -> AVRoutePickerView {
        let v = AVRoutePickerView()
        v.tintColor = UIColor(red: 232 / 255, green: 195 / 255, blue: 122 / 255, alpha: 1)
        v.activeTintColor = v.tintColor
        v.prioritizesVideoDevices = false
        return v
    }
    func updateUIView(_ uiView: AVRoutePickerView, context: Context) {}
}
