import SwiftUI
import UIKit

struct MonitorView: View {
    @EnvironmentObject var m: AppModel

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                GlassCard {
                    Text("Live monitor").font(.system(size: 18, weight: .bold)).foregroundColor(Theme.text)
                    Text(m.routeText).font(.system(size: 13)).foregroundColor(Theme.muted)
                    WaveView(samples: m.wave)
                    HStack {
                        Text("LIVE INPUT").font(.system(size: 11)).tracking(0.6).foregroundColor(Theme.muted)
                        Spacer()
                        Button(action: { m.resetClips() }) {
                            Text(m.clips > 0 ? "CLIPPING x\(m.clips) (tap to reset)" : "No clipping")
                                .font(.system(size: 12))
                                .foregroundColor(m.clips > 0 ? Color(red: 1, green: 0.42, blue: 0.42) : Theme.muted)
                        }.buttonStyle(.plain)
                    }
                    if m.howlActive {
                        Text("Feedback (howl) detected. Output turned down for a few seconds. Move the mic away from the speaker or lower the volume.")
                            .font(.system(size: 13)).foregroundColor(Color(red: 1, green: 0.42, blue: 0.42))
                    }
                }

                GlassCard {
                    HStack(alignment: .top) {
                        KnobView(title: "Input gain", value: $m.inGain, range: -24...24,
                                 format: { signed($0) + " dB" })
                        KnobView(title: "Output gain", value: $m.outGain, range: -24...6,
                                 format: { signed($0) + " dB" })
                    }
                    HStack(spacing: 8) {
                        Text("IN").font(.system(size: 11)).tracking(0.6).foregroundColor(Theme.muted).frame(width: 38, alignment: .leading)
                        SegMeter(level: m.inLevel)
                    }.padding(.top, 6)
                    HStack(spacing: 8) {
                        Text("OUT").font(.system(size: 11)).tracking(0.6).foregroundColor(Theme.muted).frame(width: 38, alignment: .leading)
                        SegMeter(level: m.outLevel)
                    }
                }

                GlassCard {
                    HStack {
                        GlassSquare(glyph: "M", caption: "Mute", active: !m.monitorOn) { m.monitorOn.toggle() }
                            .frame(maxWidth: .infinity)
                        VStack(spacing: 4) {
                            Button(action: { m.toggleRun() }) {
                                Text(m.running ? "STOP" : "START")
                                    .font(.system(size: 15, weight: .bold))
                                    .foregroundColor(m.running ? Color(red: 1, green: 0.6, blue: 0.62) : Theme.gold)
                                    .frame(width: 88, height: 88)
                                    .background(Circle().fill(m.running ? Color(red: 0.165, green: 0.063, blue: 0.075)
                                                                        : Color(red: 0.165, green: 0.137, blue: 0.071)))
                                    .overlay(Circle().stroke(m.running ? Theme.red : Theme.gold, lineWidth: 3))
                            }.buttonStyle(.plain)
                            Text("Monitoring").font(.system(size: 12)).foregroundColor(Theme.muted)
                        }.frame(maxWidth: .infinity)
                        GlassSquare(glyph: "By", caption: "Bypass", active: m.bypass) { m.bypass.toggle() }
                            .frame(maxWidth: .infinity)
                    }
                    Button(action: { m.toggleRec() }) {
                        Text(m.recording ? "STOP REC   " + String(format: "%02d:%02d", m.recSeconds / 60, m.recSeconds % 60) : "REC")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(m.recording ? .white : Color(red: 1, green: 0.54, blue: 0.56))
                            .frame(maxWidth: .infinity, minHeight: 50)
                            .background(Group {
                                if m.recording { RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color(red: 0.78, green: 0.16, blue: 0.16)) }
                                else { GlassFill(radius: 14, active: false) }
                            })
                    }.buttonStyle(.plain).padding(.top, 10)
                    Hint("REC saves what you hear, with all effects, as an M4A file. Find it in the Files app under EchoLab.")
                    Text("Use headphones. A mic next to a speaker causes acoustic howling feedback.")
                        .font(.system(size: 12)).foregroundColor(Color(red: 0.88, green: 0.63, blue: 0.38))
                }
            }
            .padding(.horizontal, 16).padding(.bottom, 24).padding(.top, 2)
        }
    }
}

struct DelayView: View {
    @EnvironmentObject var m: AppModel

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                GlassCard("Digital delay") {
                    HStack(alignment: .top) {
                        KnobView(title: "Time", value: $m.delayMs, range: 1...1500, format: { "\($0) ms" }, dragPoints: 520)
                        KnobView(title: "Feedback", value: $m.feedback, range: 0...90, format: { "\($0) %" }, dragPoints: 260)
                        KnobView(title: "Mix", value: $m.mix, range: 0...100, format: { "\($0) %" }, dragPoints: 260)
                    }
                }
                GlassCard("Delay time presets") {
                    HStack(spacing: 8) {
                        ForEach(0..<4, id: \.self) { i in
                            PresetButton(text: "\(m.delayPresets[i]) ms", active: m.delayMs == m.delayPresets[i],
                                         onTap: { m.loadDelayPreset(i) }, onHold: { m.saveDelayPreset(i) })
                        }
                    }
                    Hint("Tap to use a preset. Hold a button for 1 second to save the current delay time into it. Only that button changes.")
                }
                GlassCard("Feedback presets") {
                    HStack(spacing: 8) {
                        ForEach(0..<4, id: \.self) { i in
                            PresetButton(text: "\(m.feedbackPresets[i]) %", active: m.feedback == m.feedbackPresets[i],
                                         onTap: { m.loadFeedbackPreset(i) }, onHold: { m.saveFeedbackPreset(i) })
                        }
                    }
                    Hint("Tap to use a preset. Hold a button for 1 second to save the current feedback into it. Only that button changes.")
                }
                GlassCard("Space and dynamics") {
                    HStack(alignment: .top) {
                        KnobView(title: "Reverb", value: $m.revAmt, range: 0...100,
                                 format: { $0 == 0 ? "off" : "\($0) %" }, dragPoints: 260)
                        KnobView(title: "Room", value: $m.revRoom, range: 0...100, format: { "\($0) %" }, dragPoints: 260)
                        KnobView(title: "Compress", value: $m.comp, range: 0...100,
                                 format: { $0 == 0 ? "off" : "\($0) %" }, dragPoints: 260)
                    }
                    Hint("Compressor evens out loud and quiet parts of a voice. Reverb adds room space after the echo.")
                }
            }
            .padding(.horizontal, 16).padding(.bottom, 24).padding(.top, 2)
        }
    }
}

struct ToneView: View {
    @EnvironmentObject var m: AppModel

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                GlassCard("Tone EQ") {
                    EqCurve(bass: m.bass, mid: m.mid, treble: m.treble)
                    HStack {
                        Text("120 Hz"); Spacer(); Text("1 kHz"); Spacer(); Text("6 kHz")
                    }.font(.system(size: 11)).foregroundColor(Theme.muted)
                    HStack(alignment: .top) {
                        KnobView(title: "Bass", value: $m.bass, range: -12...12, format: { signed($0) + " dB" }, dragPoints: 260)
                        KnobView(title: "Mid", value: $m.mid, range: -12...12, format: { signed($0) + " dB" }, dragPoints: 260)
                        KnobView(title: "Treble", value: $m.treble, range: -12...12, format: { signed($0) + " dB" }, dragPoints: 260)
                    }
                    WideButton(title: "Reset tone to flat") { m.bass = 0; m.mid = 0; m.treble = 0 }
                }
                GlassCard("Protection") {
                    Toggle("Limiter (stops sudden peaks and clipping)", isOn: $m.limiter)
                        .foregroundColor(Theme.text).tint(Theme.gold)
                    Toggle("Howl protection (turns output down on feedback)", isOn: $m.howlGuard)
                        .foregroundColor(Theme.text).tint(Theme.gold)
                }
            }
            .padding(.horizontal, 16).padding(.bottom, 24).padding(.top, 2)
        }
    }
}

struct SetupView: View {
    @EnvironmentObject var m: AppModel

    private var inputLabel: String {
        if let uid = m.selectedInputUID, let p = m.inputs.first(where: { $0.uid == uid }) { return p.portName }
        return "Automatic (system default)"
    }

    private func bufferSlider(_ title: String, _ value: Binding<Int>) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(title).font(.system(size: 14)).foregroundColor(Theme.text)
                Spacer()
                Text("\(value.wrappedValue) ms").font(.system(size: 14, weight: .bold)).foregroundColor(Theme.gold)
            }
            Slider(value: Binding(get: { Double(value.wrappedValue) }, set: { value.wrappedValue = Int($0) }),
                   in: 1...100, step: 1, onEditingChanged: { editing in if !editing { m.applyBuffer() } })
                .tint(Theme.gold)
        }
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                GlassCard("Audio devices") {
                    Text("INPUT (MICROPHONE)").font(.system(size: 11)).tracking(0.6).foregroundColor(Theme.muted)
                    Menu {
                        Button("Automatic (system default)") { m.selectInput(nil) }
                        ForEach(m.inputs, id: \.uid) { p in
                            Button(p.portName) { m.selectInput(p.uid) }
                        }
                    } label: {
                        HStack {
                            Text(inputLabel).foregroundColor(Theme.gold)
                            Spacer()
                            Image(systemName: "chevron.down").foregroundColor(Theme.gold)
                        }
                        .padding(.horizontal, 14).frame(minHeight: 46)
                        .background(GlassFill(radius: 14, active: false))
                    }
                    Text("OUTPUT").font(.system(size: 11)).tracking(0.6).foregroundColor(Theme.muted).padding(.top, 6)
                    HStack {
                        Text("Choose speaker, headphones, USB-C or Bluetooth").foregroundColor(Theme.text)
                            .font(.system(size: 14))
                        Spacer()
                        RoutePicker().frame(width: 44, height: 44)
                    }
                    Text("QUICK ROUTES").font(.system(size: 11)).tracking(0.6).foregroundColor(Theme.muted).padding(.top, 6)
                    WideButton(title: "Phone mic -> USB-C out") { m.quickRoute(usbIn: false) }
                    WideButton(title: "USB-C in -> USB-C out") { m.quickRoute(usbIn: true) }
                    Toggle("Use Bluetooth headset mic (call mode, lower quality)", isOn: $m.btCallMode)
                        .foregroundColor(Theme.text).tint(Theme.gold)
                        .onChange(of: m.btCallMode) { _ in m.settingsChangedNeedsRestart() }
                    Hint("Off: your phone's mic is used and Bluetooth earbuds or speakers only play the sound (best quality). On: the Bluetooth headset's own mic is used, but iPhones then lower the audio quality.")
                }

                GlassCard("Buffers") {
                    bufferSlider("Latency buffer (wired / phone / USB-C)", $m.wiredBufMs)
                    bufferSlider("Bluetooth buffer", $m.btBufMs)
                    Text("In use now: \(String(format: "%.1f", m.actualBufMs)) ms (\(m.isBluetoothRoute ? "Bluetooth" : "wired / phone") route)")
                        .font(.system(size: 13, weight: .bold)).foregroundColor(Theme.gold)
                    Hint("The wired setting is used on speaker, wired, USB-C and phone routes, and the Bluetooth setting on Bluetooth routes. Smaller = less delay but may crackle, so raise it only until crackle stops. iPhones only offer fixed buffer sizes (roughly 3, 5, 11, 21, 43 and 85 ms), so the real value moves in steps. The line above shows what you actually got. Bluetooth adds its own large delay that no setting can remove.")
                }

                GlassCard("Latency calibration") {
                    Text(m.calText).font(.system(size: 14)).foregroundColor(Theme.text)
                    Toggle("Apply compensation to echo timing", isOn: $m.applyComp)
                        .foregroundColor(Theme.text).tint(Theme.gold)
                    HStack(spacing: 8) {
                        WideButton(title: "AUTO") { m.startMeasure() }
                        WideButton(title: "-1 ms") { m.adjustComp(-1) }
                        WideButton(title: "+1 ms") { m.adjustComp(1) }
                        WideButton(title: "RESET") { m.resetComp() }
                    }
                    Hint("AUTO plays a short noise burst and listens with the mic, so the mic must be able to hear the output (speaker near the phone, or use a loopback cable). The result is the round trip of this route including your buffer setting, and is stored per route. Compensation shifts only the echo timing so repeats land at the set delay time after your direct voice. It does not make live monitoring faster.")
                }

                GlassCard("Settings presets") {
                    ForEach(1...3, id: \.self) { n in
                        HStack(spacing: 8) {
                            Text("Preset \(n)").foregroundColor(Theme.text)
                            Spacer()
                            WideButton(title: "Save") { m.saveSlot(n) }.frame(width: 90)
                            WideButton(title: "Load") { m.loadSlot(n) }.frame(width: 90)
                        }
                    }
                    Hint("These store gains, delay, tone, reverb, compressor and switch settings. They do not store the delay and feedback preset buttons, devices, buffers or calibration.")
                }

                GlassCard("Recordings") {
                    Hint("Recordings are saved on this iPhone only, as M4A files. Open the Files app, then On My iPhone, then EchoLab. Nothing is uploaded.")
                }

                GlassCard("Audio info") {
                    Text(m.diagnostics()).font(.system(size: 13)).foregroundColor(Theme.text)
                    WideButton(title: "Noise check") { m.startNoiseCheck() }
                    WideButton(title: "Copy diagnostics") {
                        UIPasteboard.general.string = m.diagnostics()
                        m.flash("Diagnostics copied. Paste them into your message.", 3)
                    }
                    Hint("Latency figures in the info above are Apple's own estimates. Use AUTO in Latency calibration for a measured round trip.")
                }
            }
            .padding(.horizontal, 16).padding(.bottom, 24).padding(.top, 2)
        }
        .alert("Noise check", isPresented: Binding(get: { m.noiseReport != nil },
                                                    set: { if !$0 { m.noiseReport = nil } })) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(m.noiseReport ?? "")
        }
    }
}
